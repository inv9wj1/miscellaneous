import React from 'react';

function Phase3() {
  return <div>
    <h1>Phase 3</h1>
    <p>
      Phase 3 is the third phase of the project.
    </p>
    
  </div>;
}

export default Phase3;
