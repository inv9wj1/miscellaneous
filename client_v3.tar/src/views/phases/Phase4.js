import React from 'react';

function Phase4() {
  return <div>
    <h1>Phase 4</h1>
    <p>
      Phase 4 is the fourth phase of the project.
    </p>
    
  </div>;
}

export default Phase4;
