import React from 'react';

function Phase2() {
  return <div>
    <h1>Phase 2</h1>
    <p>
      Phase 2 is the second phase of the project.
    </p>
    
  </div>;
}

export default Phase2;
