
export const setLogin = () => {
  return {
    type: 'login',
    payload: '',
  };
}
export const setLogout = () => {
  return {
    type: 'logout',
    payload: '',
  };
}
