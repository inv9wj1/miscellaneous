export const ActionTypes = {
  SET_JOB_PARAMS: 'SET_JOB_PARAMS',
  SET_OUTPUT_FILES: 'SET_OUTPUT_FILES',
};
