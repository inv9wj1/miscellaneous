var express = require("express");
var router = express.Router();
const path = require("path");
const fs = require("fs");
const { JSDOM } = require("jsdom");

router.get("/test", function (req, res) {
  console.log("getting in");
  const filePath = path.resolve(`output/test.txt`);

  // Read the content of the test.txt file asynchronously
  fs.readFile(filePath, "utf8", function (err, data) {
    if (err) {
      console.error("Error reading file:", err);
      res.status(500).send("Internal Server Error");
      return;
    }

    const dom = new JSDOM(data);
    const document = dom.window.document;
    const divs = document.querySelectorAll("div");
    let final_line = ""; // Accumulate the final result here
    let endOfStringAppended = false; // Flag to track if "end of string" is appended

    divs.forEach((div) => {
      if (!endOfStringAppended) {
        // Continue processing only if "end of string" is not yet appended
        // Initialize line1 for each div
        let line1 = "";

        // Locate the span element within the current div
        const span = div.querySelector(
          "span.a-size-base-plus.a-color-base.a-text-normal"
        );

        // Check if the div contains "Sponsored" or "sponsored", and skip processing if present
        if (
          div.textContent.includes("video-store-product") ||
          div.textContent.includes("Sponsored")
        ) {
          return;
        }
        if (span) {
          // Capture the entire div
          const divContent = div.textContent.trim();

          // Search for the specified conditions inside the div
          const spans = div.querySelectorAll("span");
          spans.forEach(function (span) {
            if (
              span.classList.contains("a-size-base-plus") &&
              span.classList.contains("a-color-base") &&
              span.classList.contains("a-text-normal")
            ) {
              line1 += span.textContent.trim() + " break ";
            } else if (
              span.classList.contains("a-size-base") &&
              span.classList.contains("a-color-secondary")
            ) {
              const spanText = span.textContent.trim();
              // Ignore if the span contains "M.R.P" or "(₹"
              if (spanText.includes("M.R.P") || spanText.includes("(₹")) {
                return;
              }
              line1 += spanText + " break ";
            } else if (
              span.classList.contains("a-size-base") &&
              span.classList.contains("s-underline-text")
            ) {
              line1 += span.textContent.trim() + " break ";
            } else if (span.classList.contains("a-price-whole")) {
              line1 += span.textContent.trim() + " endOfSearchString ";
            } else if (span.classList.contains("a-icon-alt")) {
              line1 += span.textContent.trim() + " break ";
            }
          });

          // Append "** end of string **" after accumulating line1
          line1 += "** end of string **";

          // Append line1 to final_line
          final_line += line1 + "\n";

          // Set the flag to true and break the loop
          endOfStringAppended = true;
        }
      }
    });

    // Send the final result as response
    res.send(final_line);
  });
});

module.exports = router;
