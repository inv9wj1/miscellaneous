const data = [
    {
      "id": "0",
      "name": "Root",
      "isDir": true,
      "files": [
        {
          "id": "1",
          "name": "Folder 1",
          "isDir": true,
          "files": [
            {
              "id": "11",
              "name": "Sub Folder 1",
              "isDir": true,
              "files": [
                {
                  "id": "111",
                  "name": "Sub Folder 2",
                  "isDir": true,
                  "files": [
                    {
                      "id": "1111",
                      "name": "job1.txt"
                    },
                    {
                      "id": "1112",
                      "name": "job2.txt"
                    }
                  ]
                }
              ]
            }
          ]
        },
        { "id": "2", "name": "Folder 2", "isDir": true },
        { "id": "3", "name": "Folder 3", "isDir": true }
      ]
    }
  ];
  export default data;
  