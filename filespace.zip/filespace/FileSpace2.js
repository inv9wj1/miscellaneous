
//import "./styles.css";
import { setChonkyDefaults } from "chonky";
import { ChonkyIconFA } from "chonky-icon-fontawesome";
import { FullFileBrowser, ChonkyActions } from "chonky";
import { useEffect, useState } from "react";
import data from "./data";
import folderSearch from "./folderSearch";
import handleAction from "./chonkyActionHandler";
import { customActions } from "./chonkyCustomActions";
import axiosConnect from './../../api/axiosConnect';


function FileSpace() {
  const handleActionWrapper = (data) => {
    
    handleAction(data, setCurrentFolder);
  };
  console.log("start", data);
  setChonkyDefaults({ iconComponent: ChonkyIconFA });

  const [currentFolder, setCurrentFolder] = useState("0");
  const [files, setFiles] = useState(null);
  const [folderChain, setFolderChain] = useState(null);
  const fileActions = [...customActions, ChonkyActions.DownloadFiles];

  const loadAutomationData = async () => {
    // const res = await fetch("http://localhost:3000/mf/getautospacecards");
    // const resData = await res.json();
    setFiles(data);
    console.log("files--------::::::", files);

    const res = data; //await axiosConnect.get("/getautospacecards");
    // if (res.status === 201) {
    //     const resData = res.data;
    //     console.log("Data received from getautospacecards");
    //     console.log(resData);
    //     if (Array.isArray(resData) && resData.length > 0) {
    //        setAllCardData(resData);
    //     } else {
    //         setAllCardData([]);
    //     }
    // }
}; 
  useEffect(() => {
    let folderChainTemp = [];
    let filesTemp = [];

    const [found, filesTemp1, folderChainTemp1] = folderSearch(
      data,
      folderChainTemp,
      currentFolder
    );
    if (found) {
      console.log("found", filesTemp1, folderChainTemp1);
      filesTemp = filesTemp1;
      folderChainTemp = folderChainTemp1;
    }

    console.log("files", filesTemp);
    console.log("folders", folderChainTemp);
    setFolderChain(folderChainTemp);
    setFiles(filesTemp);
  }, [currentFolder]);

  return (
    <div className="App">
    <h1>File Space</h1>
    <FullFileBrowser
      files={files}
      folderChain={folderChain}
      defaultFileViewActionId={ChonkyActions.EnableListView.id}
      fileActions={fileActions}
      onFileAction={handleAction(data, setCurrentFolder)}
      disableDefaultFileActions={true}
    />
  </div>
  )

}
export default FileSpace;


