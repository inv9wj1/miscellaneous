
//import "./styles.css";
import { setChonkyDefaults } from "chonky";
import { ChonkyIconFA } from "chonky-icon-fontawesome";
import { FullFileBrowser, ChonkyActions } from "chonky";
import { useEffect, useState } from "react";
import folderSearch from "./folderSearch";
import handleAction from "./chonkyActionHandler";
import { customActions } from "./chonkyCustomActions";
import axiosConnect from './../../api/axiosConnect';


function FileSpace() {

  const [allCardData, setAllCardData] = useState([]);
  const [currentFolder, setCurrentFolder] = useState("0");
  const [files, setFiles] = useState(null);
  const [folderChain, setFolderChain] = useState(null);
  const fileActions = [...customActions, ChonkyActions.DownloadFiles];

  setChonkyDefaults({ iconComponent: ChonkyIconFA });
  const loadFileSpaceData = async () => {
    const res = await axiosConnect.get("/getFileSpaceData");
    console.log("Data received from getFileSpaceData"+res.data);
    const resData = res.data;
    setAllCardData(resData);

    let folderChainTemp = [];
  let filesTemp = [];
  const [found, filesTemp1, folderChainTemp1] = folderSearch(
    resData,
    folderChainTemp,
    currentFolder
  );
  if (found) {
    console.log("found", filesTemp1, folderChainTemp1);
    filesTemp = filesTemp1;
    folderChainTemp = folderChainTemp1;
  }

  console.log("files", filesTemp);
  console.log("folders", folderChainTemp);
  setFolderChain(folderChainTemp);
  setFiles(filesTemp);


};
const handleActionWrapper = (allCardData) => {
  handleAction(allCardData, setCurrentFolder);
};
  useEffect(() => {
    loadFileSpaceData();
  }, [currentFolder]);


  return (
    <div className="App">
    <h1>File Space</h1>
    <FullFileBrowser
      files={files}
      folderChain={folderChain}
      defaultFileViewActionId={ChonkyActions.EnableListView.id}
      fileActions={fileActions}
      onFileAction={handleActionWrapper}
      disableDefaultFileActions={true}
    />
  </div>
  )

}
export default FileSpace;


